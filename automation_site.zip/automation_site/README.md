# Sparta_Global_Sinatra_Registration_Testing_Practice

Use this site to do Automation Testing Practice. This will be hosted online in the future this can also been run locally using `rackup`.

# Application set-up

```bash
bundle
rackup
# Go to http://localhost:9292
```
